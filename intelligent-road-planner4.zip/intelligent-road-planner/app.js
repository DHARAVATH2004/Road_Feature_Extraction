const REPORTS_STORAGE_KEY = "roadintel_reports";
const AUTH_STORAGE_KEY = "roadintel_auth_accounts";
const LEGACY_USERS_STORAGE_KEY = "roadintel_users";
const getDefaultReports = () => [
  {
    id: crypto.randomUUID(),
    type: "Pothole",
    severity: 4,
    status: "new",
    notes: "Large pothole near bus stop causing swerves.",
    lat: 12.9746,
    lng: 77.5946,
    areaName: "City Center",
    hasPhoto: false,
    photoDataUrl: "",
    submittedByUser: false,
    createdAt: Date.now() - 1000 * 60 * 55
  },
  {
    id: crypto.randomUUID(),
    type: "Flooding",
    severity: 5,
    status: "in-progress",
    notes: "Waterlogging after overnight rain.",
    lat: 12.9698,
    lng: 77.6099,
    areaName: "Commercial District",
    hasPhoto: false,
    photoDataUrl: "",
    submittedByUser: false,
    createdAt: Date.now() - 1000 * 60 * 30
  },
  {
    id: crypto.randomUUID(),
    type: "Construction",
    severity: 2,
    status: "resolved",
    notes: "Temporary diversion removed.",
    lat: 12.9791,
    lng: 77.5877,
    areaName: "Industrial Park",
    hasPhoto: false,
    photoDataUrl: "",
    submittedByUser: false,
    createdAt: Date.now() - 1000 * 60 * 120
  }
];
const DEFAULT_SEED_SIGNATURES = new Set([
  "Pothole|City Center|Large pothole near bus stop causing swerves.",
  "Flooding|Commercial District|Waterlogging after overnight rain.",
  "Construction|Industrial Park|Temporary diversion removed."
]);

function isDefaultSeedReport(report) {
  const signature = `${report.type || ""}|${report.areaName || ""}|${report.notes || ""}`;
  return DEFAULT_SEED_SIGNATURES.has(signature);
}
function isCommunityReport(report) {
  return Boolean(report?.submittedByUser) || !isDefaultSeedReport(report);
}

function softmaxScores(scoresByLabel, temperature = 1) {
  const entries = Object.entries(scoresByLabel);
  const maxScore = Math.max(...entries.map(([, value]) => value));
  const expScores = entries.map(([label, value]) => [label, Math.exp((value - maxScore) / Math.max(0.1, temperature))]);
  const total = expScores.reduce((sum, [, value]) => sum + value, 0) || 1;
  return Object.fromEntries(expScores.map(([label, value]) => [label, value / total]));
}

function sigmoid(value) {
  return 1 / (1 + Math.exp(-value));
}

function computeLinearScore(features, coefficients) {
  return Object.entries(features).reduce((sum, [key, value]) => sum + value * (coefficients[key] || 0), coefficients.bias || 0);
}

function scoreMulticlassLinearModel(features, modelWeights, temperature = 1) {
  const rawScores = Object.fromEntries(
    Object.entries(modelWeights).map(([label, coefficients]) => [label, computeLinearScore(features, coefficients)])
  );
  return softmaxScores(rawScores, temperature);
}

function blendProbabilities(primaryProbs, secondaryProbs, primaryWeight = 0.72) {
  const labels = new Set([...Object.keys(primaryProbs), ...Object.keys(secondaryProbs)]);
  const blended = {};
  labels.forEach((label) => {
    const primary = primaryProbs[label] || 0;
    const secondary = secondaryProbs[label] || 0;
    blended[label] = primary * primaryWeight + secondary * (1 - primaryWeight);
  });
  return blended;
}

function normalizeReport(report) {
  const photoDataUrl = typeof report.photoDataUrl === "string" ? report.photoDataUrl : "";
  const submittedByUser = typeof report.submittedByUser === "boolean" ? report.submittedByUser : isCommunityReport(report);
  const submittedByName = typeof report.submittedByName === "string" ? report.submittedByName : "";
  const submittedByEmail = typeof report.submittedByEmail === "string" ? report.submittedByEmail : "";
  return {
    id: report.id || crypto.randomUUID(),
    type: report.type || "Pothole",
    severity: Number.isFinite(Number(report.severity)) ? Math.max(1, Math.min(5, Number(report.severity))) : 3,
    status: report.status || "new",
    notes: report.notes || "",
    lat: Number.isFinite(Number(report.lat)) ? Number(report.lat) : 12.9716,
    lng: Number.isFinite(Number(report.lng)) ? Number(report.lng) : 77.5946,
    areaName: report.areaName || "Not specified",
    hasPhoto: Boolean(photoDataUrl || report.hasPhoto),
    photoDataUrl,
    submittedByUser,
    submittedByName,
    submittedByEmail,
    createdAt: Number.isFinite(Number(report.createdAt)) ? Number(report.createdAt) : Date.now()
  };
}

function verifyDashboardConsistency(expected) {
  const hint = document.getElementById("dashboardSyncHint");
  if (!hint) return;
  const valueNodes = Array.from(document.querySelectorAll("#analyticsCards .stat-card .value"));
  const cardValues = {
    total: Number.parseInt(valueNodes[0]?.textContent || "0", 10) || 0,
    inProgress: Number.parseInt(valueNodes[1]?.textContent || "0", 10) || 0,
    resolved: Number.parseInt(valueNodes[2]?.textContent || "0", 10) || 0,
    resolutionRate: Number.parseInt((valueNodes[3]?.textContent || "0").replace("%", ""), 10) || 0
  };
  const statusFilter = document.getElementById("statusFilter")?.value || "all";
  const severityFilter = document.getElementById("severityFilter")?.value || "all";
  const expectedRows = state.reports.filter((report) => {
    if (statusFilter !== "all" && report.status !== statusFilter) return false;
    if (severityFilter !== "all" && String(report.severity) !== severityFilter) return false;
    return true;
  }).length;
  const renderedRows = document.querySelectorAll("#reportsTableBody tr").length;

  const isConsistent =
    cardValues.total === expected.total &&
    cardValues.inProgress === expected.inProgress &&
    cardValues.resolved === expected.resolved &&
    cardValues.resolutionRate === expected.resolutionRate &&
    renderedRows === expectedRows;

  if (isConsistent) {
    hint.textContent = `Dashboard synced • ${new Date().toLocaleTimeString()}`;
    hint.classList.remove("warning");
  } else {
    hint.textContent = "Dashboard mismatch detected. Refreshing data may be required.";
    hint.classList.add("warning");
    console.warn("Dashboard consistency check failed", {
      expected,
      cardValues,
      expectedRows,
      renderedRows
    });
  }
}

function loadReports() {
  try {
    const parsed = JSON.parse(localStorage.getItem(REPORTS_STORAGE_KEY) || "null");
    if (!Array.isArray(parsed) || !parsed.length) {
      const seeded = getDefaultReports().map(normalizeReport);
      localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(seeded));
      return seeded;
    }
    return parsed.map(normalizeReport);
  } catch (error) {
    const seeded = getDefaultReports().map(normalizeReport);
    localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(seeded));
    return seeded;
  }
}

function saveReports() {
  localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(state.reports.map(normalizeReport)));
}

const state = {
  role: null,
  selectedPin: null,
  selectedReportArea: null,
  currentUser: JSON.parse(localStorage.getItem("roadintel_current_user") || "null"),
  reports: loadReports()
};

const pages = {
  landing: document.getElementById("landingPage"),
  login: document.getElementById("loginPage"),
  signup: document.getElementById("signupPage"),
  role: document.getElementById("rolePage"),
  user: document.getElementById("userDashboard"),
  officer: document.getElementById("officerDashboard")
};

const featureHighlights = [
  "Route planning with distance + ETA",
  "Road quality scoring (AI-ready)",
  "Community hazard reporting with photos",
  "Municipal analytics + resolution tracking"
];
const routePalette = ["#1b78ff", "#22c55e", "#ff9f1c", "#a855f7"];
const knownPlaces = {
  "city center": { lat: 12.9746, lng: 77.5946 },
  "commercial district": { lat: 12.9698, lng: 77.6099 },
  "industrial park": { lat: 12.9791, lng: 77.5877 },
  indiranagar: { lat: 12.9719, lng: 77.6412 },
  whitefield: { lat: 12.9698, lng: 77.75 },
  "electronic city": { lat: 12.8399, lng: 77.677 },
  "mg road": { lat: 12.9758, lng: 77.6054 },
  majestic: { lat: 12.9784, lng: 77.5723 }
};

const maps = {};
const hazardLayer = L.layerGroup();
const officerLayer = L.layerGroup();
const routeLayer = L.layerGroup();
let reportPinMarker = null;
let reportAreaMarker = null;
let reportAreaCircle = null;

function showPage(key) {
  Object.values(pages).forEach((page) => page.classList.remove("active"));
  pages[key].classList.add("active");
  setTimeout(() => {
    Object.values(maps).forEach((m) => m?.invalidateSize?.());
  }, 100);
}

function setTheme(theme) {
  document.body.classList.toggle("light", theme === "light");
  localStorage.setItem("theme", theme);
}
function getEmptyCredentialStore() {
  return { user: [], officer: [] };
}

function normalizeCredentialAccount(account, fallbackRole = "user") {
  const role = account?.role === "officer" ? "officer" : fallbackRole;
  return {
    name: String(account?.name || "").trim(),
    email: String(account?.email || "").trim().toLowerCase(),
    password: String(account?.password || ""),
    role
  };
}

function getCredentialStore() {
  try {
    const parsed = JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY) || "null");
    if (!parsed || typeof parsed !== "object") return getEmptyCredentialStore();
    return {
      user: Array.isArray(parsed.user)
        ? parsed.user.map((account) => normalizeCredentialAccount(account, "user")).filter((account) => account.email)
        : [],
      officer: Array.isArray(parsed.officer)
        ? parsed.officer.map((account) => normalizeCredentialAccount(account, "officer")).filter((account) => account.email)
        : []
    };
  } catch (error) {
    return getEmptyCredentialStore();
  }
}

function saveCredentialStore(store) {
  const normalizedStore = {
    user: Array.isArray(store.user)
      ? store.user.map((account) => normalizeCredentialAccount(account, "user")).filter((account) => account.email)
      : [],
    officer: Array.isArray(store.officer)
      ? store.officer.map((account) => normalizeCredentialAccount(account, "officer")).filter((account) => account.email)
      : []
  };
  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(normalizedStore));
  localStorage.setItem(LEGACY_USERS_STORAGE_KEY, JSON.stringify([...normalizedStore.user, ...normalizedStore.officer]));
}

function migrateLegacyUsersIfNeeded() {
  if (localStorage.getItem(AUTH_STORAGE_KEY)) return;
  try {
    const legacyUsers = JSON.parse(localStorage.getItem(LEGACY_USERS_STORAGE_KEY) || "[]");
    if (!Array.isArray(legacyUsers) || !legacyUsers.length) return;
    const migrated = legacyUsers.reduce((accumulator, account) => {
      const role = account?.role === "officer" ? "officer" : "user";
      const normalized = normalizeCredentialAccount(account, role);
      if (!normalized.email) return accumulator;
      if (!accumulator[role].some((saved) => saved.email === normalized.email)) {
        accumulator[role].push(normalized);
      }
      return accumulator;
    }, getEmptyCredentialStore());
    saveCredentialStore(migrated);
  } catch (error) {
    // Ignore malformed legacy data and continue with empty credentials.
  }
}

function setCurrentUser(user) {
  state.currentUser = user;
  localStorage.setItem("roadintel_current_user", JSON.stringify(user));
}
function getSelectedMode(inputName) {
  return document.querySelector(`input[name="${inputName}"]:checked`)?.value || "user";
}
function syncReportsFromStorage() {
  state.reports = loadReports();
}

function refreshReportViews() {
  syncReportsFromStorage();
  renderHazardsAndNotifications();
  renderReportsTable();
  renderAnalytics();
}

function goToRoleDashboard(role) {
  state.role = role;
  showPage(role === "officer" ? "officer" : "user");
  refreshReportViews();
}

function login() {
  const email = document.getElementById("loginEmail").value.trim().toLowerCase();
  const password = document.getElementById("loginPassword").value;
  const selectedRole = getSelectedMode("loginMode");
  const hint = document.getElementById("loginHint");
  const credentialStore = getCredentialStore();
  const roleAccounts = selectedRole === "officer" ? credentialStore.officer : credentialStore.user;
  const user = roleAccounts.find((account) => account.email === email && account.password === password);
  if (!user) {
    const oppositeRoleAccounts = selectedRole === "officer" ? credentialStore.user : credentialStore.officer;
    const existingInOtherRole = oppositeRoleAccounts.find((account) => account.email === email);
    if (existingInOtherRole) {
      hint.textContent = `This account is registered as ${existingInOtherRole.role}. Select ${existingInOtherRole.role} mode to continue.`;
      hint.classList.add("warning");
      return;
    }
    hint.textContent = "Invalid email or password.";
    hint.classList.add("warning");
    return;
  }

  setCurrentUser({ name: user.name, email: user.email, role: user.role || selectedRole });
  hint.textContent = "";
  hint.classList.remove("warning");
  goToRoleDashboard(user.role || selectedRole);
}

function signup() {
  const name = document.getElementById("signupName").value.trim();
  const email = document.getElementById("signupEmail").value.trim().toLowerCase();
  const password = document.getElementById("signupPassword").value;
  const selectedRole = getSelectedMode("signupMode");
  const hint = document.getElementById("signupHint");
  if (!name || !email || !password) {
    hint.textContent = "All fields are required.";
    hint.classList.add("warning");
    return;
  }
  const credentialStore = getCredentialStore();
  const allAccounts = [...credentialStore.user, ...credentialStore.officer];
  if (allAccounts.some((account) => account.email === email)) {
    hint.textContent = "Account already exists. Please login.";
    hint.classList.add("warning");
    return;
  }
  if (selectedRole === "officer") {
    credentialStore.officer.push({ name, email, password, role: "officer" });
  } else {
    credentialStore.user.push({ name, email, password, role: "user" });
  }
  saveCredentialStore(credentialStore);
  setCurrentUser({ name, email, role: selectedRole });
  hint.textContent = "Account created successfully.";
  hint.classList.remove("warning");
  goToRoleDashboard(selectedRole);
}

function ensureLoggedIn(nextPage) {
  if (!state.currentUser) {
    showPage("login");
    return;
  }
  showPage(nextPage);
}

function getPriorityScore(report) {
  const sameTypeNearby = state.reports.filter(
    (r) => r.type === report.type && Math.abs(r.lat - report.lat) < 0.02 && Math.abs(r.lng - report.lng) < 0.02
  ).length;
  const statusWeight = report.status === "new" ? 2 : report.status === "in-progress" ? 1 : 0;
  return Math.min(10, report.severity + sameTypeNearby + statusWeight);
}

function statusColor(status, severity) {
  if (status === "resolved") return "green";
  return severity >= 4 ? "red" : "yellow";
}

function createCircleIcon(color) {
  return L.divIcon({
    className: "",
    html: `<span style="display:block;width:14px;height:14px;border-radius:50%;border:2px solid white;background:${color};box-shadow:0 0 0 1px #222;"></span>`,
    iconSize: [14, 14]
  });
}

function updateRouteHint(text, isError = false) {
  const hint = document.getElementById("routeApiHint");
  hint.textContent = text;
  hint.classList.toggle("warning", isError);
}

function normalizePlaceText(value) {
  return value.trim().toLowerCase().replace(/\s+/g, " ");
}

function escapeHtml(value) {
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function getKnownPlaceCoords(placeText) {
  const normalized = normalizePlaceText(placeText);
  if (knownPlaces[normalized]) return knownPlaces[normalized];
  const match = Object.entries(knownPlaces).find(([name]) => normalized.includes(name));
  return match?.[1] || null;
}

async function fetchJson(url, options, serviceName) {
  const response = await fetch(url, options);
  if (!response.ok) {
    throw new Error(`${serviceName} unavailable (${response.status}).`);
  }
  return response.json();
}

function scoreRouteQuality(distanceKm, durationMin) {
  const avgSpeed = durationMin > 0 ? distanceKm / (durationMin / 60) : 0;
  let score = 5;
  if (avgSpeed < 18) score -= 2;
  else if (avgSpeed < 26) score -= 1;
  const unresolvedHazards = state.reports.filter((r) => r.status !== "resolved" && r.severity >= 4).length;
  if (unresolvedHazards > 6) score -= 1;
  return Math.max(1, Math.min(5, score));
}

function haversineDistanceKm(pointA, pointB) {
  const toRad = (deg) => (deg * Math.PI) / 180;
  const earthRadiusKm = 6371;
  const dLat = toRad(pointB.lat - pointA.lat);
  const dLng = toRad(pointB.lng - pointA.lng);
  const lat1 = toRad(pointA.lat);
  const lat2 = toRad(pointB.lat);
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const a = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLng * sinLng;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return earthRadiusKm * c;
}

function polylineDistanceKm(points) {
  if (!points || points.length < 2) return 0;
  return points.slice(1).reduce((sum, currentPoint, idx) => {
    const previousPoint = points[idx];
    return sum + haversineDistanceKm(
      { lat: previousPoint[0], lng: previousPoint[1] },
      { lat: currentPoint[0], lng: currentPoint[1] }
    );
  }, 0);
}

function renderRouteResult(routes) {
  const summary = document.getElementById("routeSummary");
  const comparison = document.getElementById("routeComparison");
  const legend = document.getElementById("routeLegend");
  summary.innerHTML = "";
  comparison.innerHTML = "";
  legend.innerHTML = "";

  routes.forEach((route, index) => {
    const cardMarkup = `
      <div class="route-title-row">
        <span class="route-color-chip" style="background:${route.color};"></span>
        <strong>${route.name}</strong>
      </div>
      <div>${route.distanceKm.toFixed(2)} km • ${route.etaMin.toFixed(1)} min</div>
      <div class="small">Validated path: ${route.validatedDistanceKm.toFixed(2)} km (Δ ${route.distanceDeltaKm.toFixed(2)} km)</div>
    `;
    const card = document.createElement("div");
    card.className = "stat-card";
    card.innerHTML = cardMarkup;
    if (index === 0) summary.appendChild(card.cloneNode(true));
    comparison.appendChild(card);

    const legendItem = document.createElement("div");
    legendItem.className = "route-legend-item";
    legendItem.innerHTML = `
      <span class="route-color-chip" style="background:${route.color};"></span>
      <span>${route.name}: ${route.distanceKm.toFixed(2)} km</span>
    `;
    legend.appendChild(legendItem);
  });

  routeLayer.clearLayers();
  routes.forEach((route, idx) => {
    if (!route.points?.length) return;
    const lineWeight = idx === 0 ? 10 : 8;
    L.polyline(route.points, {
      color: "#0c1325",
      weight: lineWeight + 4,
      opacity: 0.42,
      lineJoin: "round",
      lineCap: "round"
    }).addTo(routeLayer);
    L.polyline(route.points, {
      color: route.color,
      weight: lineWeight,
      opacity: 0.94,
      lineJoin: "round",
      lineCap: "round"
    })
      .addTo(routeLayer)
      .bindPopup(`${route.name}<br/>Distance: ${route.distanceKm.toFixed(2)} km<br/>ETA: ${route.etaMin.toFixed(1)} min`);
  });
  const boundsPoints = routes.flatMap((r) => r.points || []);
  if (boundsPoints.length) {
    const firstRoute = routes[0]?.points || [];
    if (firstRoute.length > 1) {
      L.marker(firstRoute[0]).addTo(routeLayer).bindPopup("Start");
      L.marker(firstRoute[firstRoute.length - 1]).addTo(routeLayer).bindPopup("Destination");
    }
    maps.userRouteMap.fitBounds(L.latLngBounds(boundsPoints).pad(0.2));
  }
}

async function geocodePlace(placeText) {
  const known = getKnownPlaceCoords(placeText);
  if (known) return known;

  const query = encodeURIComponent(placeText);
  const providers = [
    {
      name: "Nominatim",
      url: `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=${query}`,
      parse: (data) => {
        if (!Array.isArray(data) || !data.length) return null;
        return { lat: Number(data[0].lat), lng: Number(data[0].lon) };
      }
    },
    {
      name: "Maps.co",
      url: `https://geocode.maps.co/search?q=${query}`,
      parse: (data) => {
        if (!Array.isArray(data) || !data.length) return null;
        return { lat: Number(data[0].lat), lng: Number(data[0].lon) };
      }
    }
  ];

  for (const provider of providers) {
    try {
      const data = await fetchJson(provider.url, { headers: { Accept: "application/json" } }, provider.name);
      const parsed = provider.parse(data);
      if (parsed && Number.isFinite(parsed.lat) && Number.isFinite(parsed.lng)) return parsed;
    } catch (error) {
      continue;
    }
  }

  throw new Error(`Unable to locate "${placeText}". Try a nearby landmark or area name.`);
}

function decodePolyline(polylineStr) {
  let index = 0;
  const len = polylineStr.length;
  let lat = 0;
  let lng = 0;
  const coordinates = [];
  while (index < len) {
    let b;
    let shift = 0;
    let result = 0;
    do {
      b = polylineStr.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlat = result & 1 ? ~(result >> 1) : result >> 1;
    lat += dlat;
    shift = 0;
    result = 0;
    do {
      b = polylineStr.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlng = result & 1 ? ~(result >> 1) : result >> 1;
    lng += dlng;
    coordinates.push([lat / 1e5, lng / 1e5]);
  }
  return coordinates;
}


function toRouteCandidate(points, distanceKm, etaMin) {
  const validatedDistanceKm = polylineDistanceKm(points);
  return {
    distanceKm,
    validatedDistanceKm,
    distanceDeltaKm: Math.abs(distanceKm - validatedDistanceKm),
    etaMin,
    qualityScore: scoreRouteQuality(distanceKm, etaMin),
    points
  };
}

async function fetchOsrmRoutes(originPoint, destinationPoint) {
  const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${originPoint.lng},${originPoint.lat};${destinationPoint.lng},${destinationPoint.lat}?alternatives=true&overview=full&geometries=polyline`;
  const routeJson = await fetchJson(osrmUrl, {}, "Route service");
  if (!routeJson.routes?.length) throw new Error("No routes found.");
  return routeJson.routes.map((route) => {
    const points = route.geometry ? decodePolyline(route.geometry) : [[originPoint.lat, originPoint.lng], [destinationPoint.lat, destinationPoint.lng]];
    const distanceKm = route.distance / 1000;
    const etaMin = route.duration / 60;
    return toRouteCandidate(points, distanceKm, etaMin);
  });
}

function openGoogleMapsLiveRoute() {
  const origin = document.getElementById("originInput").value.trim();
  const destination = document.getElementById("destinationInput").value.trim();
  if (!origin || !destination) {
    updateRouteHint("Enter both source and destination before opening Google Maps.", true);
    return;
  }
  const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&travelmode=driving`;
  window.open(googleMapsUrl, "_blank", "noopener,noreferrer");
  updateRouteHint("Opened Google Maps for live traffic distance and ETA.");
}

async function fetchBestRoutes() {
  const origin = document.getElementById("originInput").value.trim();
  const destination = document.getElementById("destinationInput").value.trim();
  if (!origin || !destination) {
    updateRouteHint("Enter both source and destination.", true);
    return;
  }

  try {
    updateRouteHint("Finding shortest routes for in-app analysis...");
    const [from, to] = await Promise.all([geocodePlace(origin), geocodePlace(destination)]);
    let candidateRoutes = [];
    try {
      candidateRoutes = await fetchOsrmRoutes(from, to);
    } catch (error) {
      const directDistanceKm = haversineDistanceKm(from, to);
      candidateRoutes = [
        toRouteCandidate([[from.lat, from.lng], [to.lat, to.lng]], directDistanceKm, (directDistanceKm / 35) * 60)
      ];
      updateRouteHint("Route service unreachable. Showing shortest direct estimate.", true);
    }

    const uniqueRoutes = candidateRoutes.filter((route, idx, allRoutes) => {
      const signature = `${route.distanceKm.toFixed(2)}-${route.etaMin.toFixed(1)}`;
      return idx === allRoutes.findIndex((otherRoute) => `${otherRoute.distanceKm.toFixed(2)}-${otherRoute.etaMin.toFixed(1)}` === signature);
    });

    const routes = uniqueRoutes
      .sort((a, b) => a.distanceKm - b.distanceKm || a.etaMin - b.etaMin)
      .slice(0, 3)
      .map((route, idx) => ({
        ...route,
        name: idx === 0 ? "Shortest Route" : `Alternate ${idx}`,
        color: routePalette[idx % routePalette.length]
      }));

    renderRouteResult(routes);
    updateRouteHint("In-app shortest route analysis loaded. Use Open in Google Maps for live traffic ETA/distance.");
  } catch (error) {
    updateRouteHint(error.message || "Unable to fetch routes right now. Please try again.", true);
  }
}

function renderHazardsAndNotifications() {
  hazardLayer.clearLayers();
  officerLayer.clearLayers();
  const feed = document.getElementById("notificationFeed");
  if (feed) feed.innerHTML = "";

  const sorted = [...state.reports].sort((a, b) => b.createdAt - a.createdAt);
  sorted.forEach((report) => {
    const colorName = statusColor(report.status, report.severity);
    const colorHex = colorName === "red" ? "#ff5757" : colorName === "yellow" ? "#ffcd58" : "#59dd7e";
    const safeNotes = report.notes ? escapeHtml(report.notes) : "No additional notes";
    const photoMarkup = report.photoDataUrl
      ? `<div style="margin-top:6px;"><img src="${report.photoDataUrl}" alt="Report evidence" style="width:130px;height:84px;object-fit:cover;border-radius:8px;border:1px solid rgba(255,255,255,.28);" /></div>`
      : `<div style="margin-top:6px;color:#95a7cf;">No photo provided</div>`;
    const marker = L.marker([report.lat, report.lng], { icon: createCircleIcon(colorHex) }).bindPopup(
      `<strong>${report.type}</strong><br/>Area: ${report.areaName || "Not specified"}<br/>Severity ${report.severity}<br/>Status: ${report.status}<br/>Priority: ${getPriorityScore(report)}<br/>Notes: ${safeNotes}${photoMarkup}`
    );
    marker.addTo(hazardLayer);
    marker.addTo(officerLayer);

    if (feed) {
      const li = document.createElement("li");
      li.textContent = `${report.type} • ${report.areaName || "Not specified"} (${report.status}) • Severity ${report.severity} • ${report.photoDataUrl ? "Photo attached" : "No photo"} • ${timeAgo(report.createdAt)}`;
      feed.appendChild(li);
    }
  });
}

function renderReportsTable() {
  const statusFilter = document.getElementById("statusFilter").value;
  const severityFilter = document.getElementById("severityFilter").value;
  const body = document.getElementById("reportsTableBody");
  body.innerHTML = "";

  const filtered = state.reports.filter((r) => {
    if (statusFilter !== "all" && r.status !== statusFilter) return false;
    if (severityFilter !== "all" && String(r.severity) !== severityFilter) return false;
    return true;
  });

  filtered
    .sort((a, b) => getPriorityScore(b) - getPriorityScore(a))
    .forEach((report) => {
      const notesText = report.notes ? escapeHtml(report.notes) : "No additional notes";
      const reportedBy = report.submittedByName || report.submittedByEmail || (isCommunityReport(report) ? "Community user" : "System seed");
      const photoCell = report.photoDataUrl
        ? `<img src="${report.photoDataUrl}" alt="Report photo" class="report-photo-thumb" />`
        : `<span class="cell-subtext">No photo</span>`;
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>
          <strong>${report.type}</strong>
          <div class="cell-subtext">Area: ${report.areaName || "Not specified"}</div>
          <div class="cell-subtext">Reported by: ${escapeHtml(reportedBy)}</div>
          <div class="cell-subtext">Notes: ${notesText}</div>
          <div class="cell-subtext">Submitted: ${new Date(report.createdAt).toLocaleString()}</div>
        </td>
        <td>${report.severity}</td>
        <td>${report.status}</td>
        <td>${getPriorityScore(report)}</td>
        <td>${photoCell}</td>
        <td>
          <button class="status-btn" data-id="${report.id}" data-action="set-status" data-next="in-progress" ${report.status === "resolved" ? "disabled" : ""}>→ In-Progress</button>
          <button class="status-btn" data-id="${report.id}" data-action="set-status" data-next="resolved" ${report.status === "resolved" ? "disabled" : ""}>✓ Resolve</button>
          <button class="status-btn delete-btn" data-id="${report.id}" data-action="delete" ${report.status === "resolved" ? "" : "disabled"}>🗑 Delete</button>
        </td>
      `;
      body.appendChild(row);
    });
}

function renderAnalytics() {
  const analyticsReports = state.reports;
  const total = analyticsReports.length;
  const resolved = analyticsReports.filter((r) => r.status === "resolved").length;
  const inProgress = analyticsReports.filter((r) => r.status === "in-progress").length;
  const resolutionRate = total ? Math.round((resolved / total) * 100) : 0;

  const cards = document.getElementById("analyticsCards");
  cards.innerHTML = `
    <div class="stat-card"><div>Total Reports</div><div class="value">${total}</div></div>
    <div class="stat-card"><div>In Progress</div><div class="value">${inProgress}</div></div>
    <div class="stat-card"><div>Resolved</div><div class="value">${resolved}</div></div>
    <div class="stat-card"><div>Resolution Rate</div><div class="value">${resolutionRate}%</div></div>
  `;

  const issueBuckets = ["Pothole", "Flooding", "Accident", "Construction"];
  const issueCounts = Object.fromEntries(issueBuckets.map((k) => [k, 0]));
  analyticsReports.forEach((r) => {
    issueCounts[r.type] = (issueCounts[r.type] || 0) + 1;
  });

  const charts = document.getElementById("charts");
  charts.innerHTML = `
    <div class="chart-panel">
      <h4>Issue Trends</h4>
      ${issueBuckets
        .map((key) => {
          const pct = total ? Math.max(10, Math.round((issueCounts[key] / total) * 100)) : 0;
          return `<div class="bar-row"><label>${key} (${issueCounts[key]})</label><div class="bar"><span style="width:${pct}%"></span></div></div>`;
        })
        .join("")}
    </div>
    <div class="chart-panel">
      <h4>Status Distribution</h4>
      ${["new", "in-progress", "resolved"]
        .map((status) => {
          const count = analyticsReports.filter((r) => r.status === status).length;
          const pct = total ? Math.max(10, Math.round((count / total) * 100)) : 0;
          return `<div class="bar-row"><label>${status} (${count})</label><div class="bar"><span style="width:${pct}%"></span></div></div>`;
        })
        .join("")}
    </div>
  `;
  verifyDashboardConsistency({ total, resolved, inProgress, resolutionRate });
}

function clampValue(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function rgbToHsv(r, g, b) {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const cMax = Math.max(rn, gn, bn);
  const cMin = Math.min(rn, gn, bn);
  const delta = cMax - cMin;
  let h = 0;
  if (delta !== 0) {
    if (cMax === rn) h = 60 * (((gn - bn) / delta) % 6);
    else if (cMax === gn) h = 60 * ((bn - rn) / delta + 2);
    else h = 60 * ((rn - gn) / delta + 4);
  }
  if (h < 0) h += 360;
  const s = cMax === 0 ? 0 : delta / cMax;
  const v = cMax;
  return { h, s, v };
}

async function loadImagePixelsFromFile(file, maxDimension = 380) {
  let cleanup = () => {};
  let sourceWidth = 0;
  let sourceHeight = 0;
  let drawSource;
  try {
    if (typeof createImageBitmap === "function") {
      const bitmap = await createImageBitmap(file);
      sourceWidth = bitmap.width;
      sourceHeight = bitmap.height;
      drawSource = (ctx, width, height) => ctx.drawImage(bitmap, 0, 0, width, height);
      cleanup = () => bitmap.close?.();
    } else {
      const objectUrl = URL.createObjectURL(file);
      cleanup = () => URL.revokeObjectURL(objectUrl);
      const image = await new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error("Unable to read image."));
        img.src = objectUrl;
      });
      sourceWidth = image.naturalWidth || image.width;
      sourceHeight = image.naturalHeight || image.height;
      drawSource = (ctx, width, height) => ctx.drawImage(image, 0, 0, width, height);
    }

    const scale = Math.min(1, maxDimension / Math.max(sourceWidth, sourceHeight));
    const width = Math.max(1, Math.round(sourceWidth * scale));
    const height = Math.max(1, Math.round(sourceHeight * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    drawSource(ctx, width, height);
    const imageData = ctx.getImageData(0, 0, width, height);
    return {
      width,
      height,
      pixelData: imageData.data
    };
  } finally {
    cleanup();
  }
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
    reader.onerror = () => reject(new Error("Unable to read image file."));
    reader.readAsDataURL(file);
  });
}

function extractImageMetrics(pixelData, width, height) {
  const pixelCount = width * height;
  const luminance = new Float32Array(pixelCount);
  let sumLuma = 0;
  let sumLumaSq = 0;
  let sumSat = 0;
  let darkCount = 0;
  let neutralCount = 0;
  let warmCount = 0;
  let vegetationCount = 0;
  let builtUpCount = 0;
  let waterCount = 0;
  let bareSoilCount = 0;
  let shadowCount = 0;
  let otherCount = 0;

  for (let p = 0, i = 0; p < pixelCount; p++, i += 4) {
    const r = pixelData[i];
    const g = pixelData[i + 1];
    const b = pixelData[i + 2];
    const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    luminance[p] = luma;
    sumLuma += luma;
    sumLumaSq += luma * luma;

    const { h, s, v } = rgbToHsv(r, g, b);
    sumSat += s;
    if (luma < 72) darkCount += 1;
    if (s < 0.16) neutralCount += 1;
    if (h >= 15 && h <= 58 && s > 0.2) warmCount += 1;

    if (v < 0.18) shadowCount += 1;
    else if (h >= 70 && h <= 170 && s > 0.22 && g >= r * 0.95 && g >= b * 0.95) vegetationCount += 1;
    else if (h >= 180 && h <= 250 && s > 0.18 && b > g * 1.02) waterCount += 1;
    else if (s < 0.18 && v > 0.32) builtUpCount += 1;
    else if (h >= 15 && h <= 55 && s > 0.2 && r > g && g >= b * 0.88) bareSoilCount += 1;
    else otherCount += 1;
  }

  let edgeCount = 0;
  const edgeTotal = Math.max(1, (width - 1) * (height - 1));
  for (let y = 0; y < height - 1; y++) {
    for (let x = 0; x < width - 1; x++) {
      const idx = y * width + x;
      const gradX = Math.abs(luminance[idx] - luminance[idx + 1]);
      const gradY = Math.abs(luminance[idx] - luminance[idx + width]);
      if ((gradX + gradY) / 2 > 22) edgeCount += 1;
    }
  }

  const meanLuma = sumLuma / pixelCount;
  const lumaStd = Math.sqrt(Math.max(0, sumLumaSq / pixelCount - meanLuma * meanLuma));
  const edgeDensity = edgeCount / edgeTotal;
  const roughnessIndex = clampValue((lumaStd / 64) * 0.55 + edgeDensity * 0.45, 0, 1);
  const percent = (count) => (count / pixelCount) * 100;

  return {
    pixelCount,
    width,
    height,
    meanLuma,
    lumaStd,
    meanSat: sumSat / pixelCount,
    edgeDensity,
    roughnessIndex,
    darkPct: percent(darkCount),
    neutralPct: percent(neutralCount),
    warmPct: percent(warmCount),
    cover: {
      vegetation: percent(vegetationCount),
      builtUp: percent(builtUpCount),
      water: percent(waterCount),
      bareSoil: percent(bareSoilCount),
      shadow: percent(shadowCount),
      other: percent(otherCount)
    }
  };
}


function summarizeRoadSurface(metrics) {
  const satPct = metrics.meanSat * 100;
  const featureVector = {
    brightness: metrics.meanLuma / 255,
    saturation: metrics.meanSat,
    darkShare: metrics.darkPct / 100,
    neutralShare: metrics.neutralPct / 100,
    warmShare: metrics.warmPct / 100,
    roughness: metrics.roughnessIndex,
    edge: metrics.edgeDensity,
    bareSoilShare: metrics.cover.bareSoil / 100,
    builtUpShare: metrics.cover.builtUp / 100
  };
  const surfaceModelWeights = {
    Bituminous: { bias: 1.22, brightness: -1.35, saturation: -0.62, darkShare: 1.56, neutralShare: 0.52, warmShare: -0.2, roughness: 0.44, edge: 0.36, bareSoilShare: -0.34, builtUpShare: 0.2 },
    Concrete: { bias: 0.98, brightness: 1.22, saturation: -0.9, darkShare: -0.76, neutralShare: 1.27, warmShare: -0.32, roughness: -0.68, edge: -0.54, bareSoilShare: -0.3, builtUpShare: 0.3 },
    "Interlocking Blocks": { bias: 0.58, brightness: 0.72, saturation: 0.36, darkShare: -0.52, neutralShare: 0.1, warmShare: 0.9, roughness: 0.15, edge: 1.42, bareSoilShare: 0.18, builtUpShare: 0.2 },
    Gravel: { bias: 0.42, brightness: 0.26, saturation: 0.61, darkShare: -0.22, neutralShare: -0.4, warmShare: 0.73, roughness: 1.3, edge: 1.06, bareSoilShare: 0.66, builtUpShare: -0.2 },
    Earthen: { bias: 0.34, brightness: 0.14, saturation: 1.04, darkShare: -0.34, neutralShare: -0.75, warmShare: 1.29, roughness: 0.88, edge: 0.5, bareSoilShare: 1.24, builtUpShare: -0.26 }
  };
  const modelProbs = scoreMulticlassLinearModel(featureVector, surfaceModelWeights, 0.46);

  const priorScores = {
    Bituminous:
      metrics.darkPct * 0.36 +
      (100 - satPct) * 0.2 +
      (1 - Math.abs(metrics.roughnessIndex - 0.5)) * 100 * 0.24 +
      metrics.neutralPct * 0.2,
    Concrete:
      (Math.max(0, metrics.meanLuma - 92) / 163) * 100 * 0.35 +
      metrics.neutralPct * 0.31 +
      (1 - metrics.roughnessIndex) * 100 * 0.2 +
      (100 - satPct) * 0.14,
    "Interlocking Blocks":
      metrics.edgeDensity * 100 * 0.44 +
      metrics.warmPct * 0.26 +
      satPct * 0.18 +
      (1 - Math.abs(metrics.meanLuma - 138) / 138) * 100 * 0.12,
    Gravel:
      metrics.roughnessIndex * 100 * 0.43 +
      metrics.warmPct * 0.31 +
      satPct * 0.15 +
      (100 - metrics.neutralPct) * 0.11,
    Earthen:
      metrics.warmPct * 0.5 +
      satPct * 0.24 +
      metrics.roughnessIndex * 100 * 0.17 +
      (100 - metrics.neutralPct) * 0.09
  };
  const priorProbs = softmaxScores(priorScores, 16);
  const classProbabilities = blendProbabilities(modelProbs, priorProbs, 0.74);
  const rankedClasses = Object.entries(classProbabilities).sort((a, b) => b[1] - a[1]);
  const surfaceType = rankedClasses[0][0];
  const topProb = rankedClasses[0][1];
  const secondProb = rankedClasses[1]?.[1] || 0;

  const distressIndex = sigmoid(
    -1.36 +
      featureVector.roughness * 3.1 +
      featureVector.edge * 2.02 +
      featureVector.darkShare * 1.15 +
      featureVector.bareSoilShare * 1.08 -
      featureVector.neutralShare * 0.71
  );
  let condition = "Good";
  let maintenance = "Routine preventive sealing is sufficient.";
  if (distressIndex > 0.8) {
    condition = "Very Poor";
    maintenance = "Immediate structural rehabilitation/reconstruction is recommended.";
  } else if (distressIndex > 0.62) {
    condition = "Poor";
    maintenance = "Overlay with structural patching and crack treatment is recommended.";
  } else if (distressIndex > 0.44) {
    condition = "Fair";
    maintenance = "Plan crack sealing and localized patch maintenance.";
  }
  const confidence = clampValue(
    0.56 + topProb * 0.3 + (topProb - secondProb) * 0.23 + Math.min(0.05, metrics.pixelCount / 230000),
    0.56,
    0.97
  );
  return {
    surfaceType,
    condition,
    confidence,
    distressIndex,
    maintenance
  };
}

function riskLabel(score) {
  if (score >= 0.66) return "High";
  if (score >= 0.4) return "Moderate";
  return "Low";
}

function summarizeFeasibility(metrics) {
  const { vegetation, builtUp, water, bareSoil, shadow, other } = metrics.cover;
  const normalized = {
    vegetation: vegetation / 100,
    builtUp: builtUp / 100,
    water: water / 100,
    bareSoil: bareSoil / 100,
    shadow: shadow / 100,
    other: other / 100,
    roughness: metrics.roughnessIndex,
    edge: metrics.edgeDensity,
    brightness: metrics.meanLuma / 255
  };
  const drainageRisk = sigmoid(-1.5 + normalized.water * 4.7 + normalized.shadow * 1.15 + normalized.edge * 1.05 - normalized.brightness * 0.9);
  const subgradeRisk = sigmoid(-1.36 + normalized.bareSoil * 4.2 + normalized.roughness * 2.5 + normalized.edge * 1.35);
  const utilityConstraint = sigmoid(-1.55 + normalized.builtUp * 4.85 + normalized.edge * 1.65 + normalized.shadow * 1.1);
  const ecoSensitivity = sigmoid(-1.62 + normalized.vegetation * 3.4 + normalized.water * 1.75 + (1 - normalized.builtUp) * 0.75);

  const modelFeatures = {
    ...normalized,
    drainageRisk,
    subgradeRisk,
    utilityConstraint,
    ecoSensitivity
  };
  const roadModelWeights = {
    "Dense Bituminous Pavement": { bias: 1.28, builtUp: 1.05, drainageRisk: -1.25, subgradeRisk: -1.16, utilityConstraint: -0.74, ecoSensitivity: -0.5, roughness: -0.3 },
    "Rigid Concrete Pavement with Integrated Drainage": { bias: 0.82, water: 0.75, builtUp: 0.15, drainageRisk: 1.7, utilityConstraint: 0.22, ecoSensitivity: -0.44, brightness: -0.22 },
    "Urban Concrete Pavement": { bias: 0.78, builtUp: 1.85, utilityConstraint: 1.32, drainageRisk: -0.26, ecoSensitivity: -0.35, edge: 0.28 },
    "Composite Pavement (Stabilized Base + Bituminous Wearing Course)": { bias: 0.85, bareSoil: 0.82, roughness: 0.46, subgradeRisk: 1.85, utilityConstraint: -0.4 },
    "Flexible Bituminous Pavement with Geotextile Reinforcement": { bias: 0.72, vegetation: 0.9, ecoSensitivity: 1.55, builtUp: -0.74, drainageRisk: -0.32, water: 0.24 }
  };
  const modelProbs = scoreMulticlassLinearModel(modelFeatures, roadModelWeights, 0.52);

  const rulePriorScores = {
    "Dense Bituminous Pavement": 2.1 - drainageRisk * 1.22 - subgradeRisk * 1.03 - utilityConstraint * 0.74 - ecoSensitivity * 0.48 + normalized.builtUp * 0.4,
    "Rigid Concrete Pavement with Integrated Drainage": 1.62 + drainageRisk * 1.48 + utilityConstraint * 0.34 - ecoSensitivity * 0.33 + normalized.water * 0.5,
    "Urban Concrete Pavement": 1.38 + utilityConstraint * 1.28 + normalized.builtUp * 1.05 - drainageRisk * 0.31 - ecoSensitivity * 0.35,
    "Composite Pavement (Stabilized Base + Bituminous Wearing Course)": 1.42 + subgradeRisk * 1.42 + normalized.bareSoil * 0.64 - utilityConstraint * 0.4,
    "Flexible Bituminous Pavement with Geotextile Reinforcement": 1.08 + ecoSensitivity * 1.22 + normalized.vegetation * 0.58 - normalized.builtUp * 0.44 - drainageRisk * 0.26
  };
  const priorProbs = softmaxScores(rulePriorScores, 0.7);
  const roadProbabilities = blendProbabilities(modelProbs, priorProbs, 0.76);
  const rankedRoadTypes = Object.entries(roadProbabilities).sort((a, b) => b[1] - a[1]);
  const roadType = rankedRoadTypes[0][0];

  const recommendationDetails = {
    "Dense Bituminous Pavement": {
      reason: "Balanced land-cover mix with moderate constraints supports flexible pavement economics.",
      addOns: "Provide routine side drains and periodic seal-coat renewal."
    },
    "Rigid Concrete Pavement with Integrated Drainage": {
      reason: "Water-prone area indicates higher flood/stagnation risk where rigid pavement performs better.",
      addOns: "Use longitudinal drains, cross-fall correction, and culvert connectivity."
    },
    "Urban Concrete Pavement": {
      reason: "Dense built-up surroundings require stronger load tolerance and lower rutting in stop-go traffic.",
      addOns: "Utility-duct corridor planning and staged jointed slab design are advised."
    },
    "Composite Pavement (Stabilized Base + Bituminous Wearing Course)": {
      reason: "Subgrade instability suggests stabilizing base layers before flexible top-surface placement.",
      addOns: "Lime/cement soil stabilization plus geogrid reinforcement is recommended."
    },
    "Flexible Bituminous Pavement with Geotextile Reinforcement": {
      reason: "Eco-sensitive area with lower urban density favors reduced construction footprint and adaptive maintenance.",
      addOns: "Use bio-swales, permeable shoulders, and strict tree-root protection during construction."
    }
  };

  const feasibilityScore = Math.round(clampValue(100 - (drainageRisk * 33 + subgradeRisk * 31 + utilityConstraint * 23 + ecoSensitivity * 13), 26, 97));
  const topProbability = rankedRoadTypes[0]?.[1] || 0;
  const secondProbability = rankedRoadTypes[1]?.[1] || 0;
  const confidence = clampValue(
    0.58 + topProbability * 0.25 + (topProbability - secondProbability) * 0.22 + Math.min(0.08, metrics.pixelCount / 250000),
    0.58,
    0.96
  );

  return {
    coverage: { vegetation, builtUp, water, bareSoil, shadow, other },
    drainageRisk,
    subgradeRisk,
    utilityConstraint,
    ecoSensitivity,
    roughnessPct: metrics.roughnessIndex * 100,
    edgeDensityPct: metrics.edgeDensity * 100,
    brightness: metrics.meanLuma,
    roadType,
    reason: recommendationDetails[roadType].reason,
    addOns: recommendationDetails[roadType].addOns,
    feasibilityScore,
    confidence
  };
}
async function analyzeRoadSurface() {
  const input = document.getElementById("surfaceImageInput");
  const out = document.getElementById("surfaceResult");
  if (!input.files.length) {
    out.textContent = "Upload a road-surface image first, then click Analyze Surface.";
    return;
  }
  try {
    out.textContent = "Analyzing uploaded road image...";
    const { pixelData, width, height } = await loadImagePixelsFromFile(input.files[0], 360);
    const metrics = extractImageMetrics(pixelData, width, height);
    const result = summarizeRoadSurface(metrics);
    out.innerHTML = `
      <strong>Predicted Surface:</strong> ${result.surfaceType}<br/>
      <strong>Condition:</strong> ${result.condition}<br/>
      <strong>Confidence:</strong> ${(result.confidence * 100).toFixed(1)}%<br/>
      <strong>Feature Summary:</strong><br/>
      • Brightness: ${metrics.meanLuma.toFixed(1)} / 255<br/>
      • Texture roughness: ${(metrics.roughnessIndex * 100).toFixed(1)}%<br/>
      • Edge density: ${(metrics.edgeDensity * 100).toFixed(1)}%<br/>
      • Dark patch share: ${metrics.darkPct.toFixed(1)}%<br/>
      • Neutral aggregate share: ${metrics.neutralPct.toFixed(1)}%<br/>
      <strong>Distress Index:</strong> ${(result.distressIndex * 100).toFixed(1)}%<br/>
      <strong>Maintenance Advice:</strong> ${result.maintenance}
    `;
  } catch (error) {
    out.textContent = `Surface analysis failed: ${error.message}`;
  }
}

async function runFeasibilityAnalysis() {
  const out = document.getElementById("feasibilityResult");
  const satInput = document.getElementById("satImageInput");
  if (!satInput.files.length) {
    out.textContent = "Upload a satellite/drone area image first, then click Run Feasibility.";
    return;
  }
  try {
    out.textContent = "Analyzing uploaded area image...";
    const { pixelData, width, height } = await loadImagePixelsFromFile(satInput.files[0], 420);
    const metrics = extractImageMetrics(pixelData, width, height);
    const result = summarizeFeasibility(metrics);
    out.innerHTML = `
      <strong>Land-Cover Distribution (from image):</strong><br/>
      • Vegetation: ${result.coverage.vegetation.toFixed(1)}%<br/>
      • Built-up: ${result.coverage.builtUp.toFixed(1)}%<br/>
      • Water/wet zone: ${result.coverage.water.toFixed(1)}%<br/>
      • Bare soil: ${result.coverage.bareSoil.toFixed(1)}%<br/>
      • Shadow/low-visibility: ${result.coverage.shadow.toFixed(1)}%<br/>
      • Other terrain: ${result.coverage.other.toFixed(1)}%<br/>
      <strong>Derived Site Features:</strong><br/>
      • Terrain roughness: ${result.roughnessPct.toFixed(1)}%<br/>
      • Structural edge density: ${result.edgeDensityPct.toFixed(1)}%<br/>
      • Brightness index: ${result.brightness.toFixed(1)} / 255<br/>
      • Drainage risk: ${riskLabel(result.drainageRisk)} (${(result.drainageRisk * 100).toFixed(1)}%)<br/>
      • Subgrade instability risk: ${riskLabel(result.subgradeRisk)} (${(result.subgradeRisk * 100).toFixed(1)}%)<br/>
      • Urban utility constraint: ${riskLabel(result.utilityConstraint)} (${(result.utilityConstraint * 100).toFixed(1)}%)<br/>
      • Eco sensitivity: ${riskLabel(result.ecoSensitivity)} (${(result.ecoSensitivity * 100).toFixed(1)}%)<br/>
      <strong>Recommended Road Type:</strong> ${result.roadType}<br/>
      <strong>Why suitable:</strong> ${result.reason}<br/>
      <strong>Design add-ons:</strong> ${result.addOns}<br/>
      <strong>Feasibility Score:</strong> ${result.feasibilityScore}/100<br/>
      <strong>Confidence:</strong> ${(result.confidence * 100).toFixed(1)}%
    `;
  } catch (error) {
    out.textContent = `Feasibility analysis failed: ${error.message}`;
  }
}
async function focusReportArea() {
  const areaInput = document.getElementById("reportAreaInput");
  const areaHint = document.getElementById("reportAreaHint");
  const areaName = areaInput.value.trim();
  if (!areaName) {
    areaHint.textContent = "Enter an area name before searching.";
    areaHint.classList.add("warning");
    return;
  }

  try {
    areaHint.textContent = "Locating area...";
    areaHint.classList.remove("warning");
    const area = await geocodePlace(areaName);
    state.selectedReportArea = { name: areaName, lat: area.lat, lng: area.lng };
    state.selectedPin = null;
    if (reportPinMarker) maps.reportMap.removeLayer(reportPinMarker);

    if (reportAreaMarker) maps.reportMap.removeLayer(reportAreaMarker);
    if (reportAreaCircle) maps.reportMap.removeLayer(reportAreaCircle);
    reportPinMarker = null;
    reportAreaMarker = L.marker([area.lat, area.lng]).addTo(maps.reportMap).bindPopup(`Area: ${areaName}`).openPopup();
    reportAreaCircle = L.circle([area.lat, area.lng], {
      radius: 1300,
      color: "#4f9dff",
      fillColor: "#4f9dff",
      fillOpacity: 0.12,
      weight: 2,
      dashArray: "5 5"
    }).addTo(maps.reportMap);

    maps.reportMap.fitBounds(reportAreaCircle.getBounds().pad(0.35));
    areaHint.textContent = `Area found: ${areaName}. Click map to place the exact problem pin.`;
    areaHint.classList.remove("warning");
    document.getElementById("pinHint").textContent = "Now click the map to mark exact issue location.";
    document.getElementById("pinHint").classList.remove("warning");
  } catch (error) {
    areaHint.textContent = error.message;
    areaHint.classList.add("warning");
  }
}

async function submitUserReport() {
  const areaInput = document.getElementById("reportAreaInput").value.trim();
  if (!areaInput) {
    document.getElementById("reportAreaHint").textContent = "Please enter and find the area before submitting.";
    document.getElementById("reportAreaHint").classList.add("warning");
    return;
  }
  if (!state.selectedReportArea || state.selectedReportArea.name.toLowerCase() !== areaInput.toLowerCase()) {
    document.getElementById("reportAreaHint").textContent = "Please click \"Find Area\" for the entered area first.";
    document.getElementById("reportAreaHint").classList.add("warning");
    return;
  }
  if (!state.selectedPin) {
    document.getElementById("pinHint").textContent = "Please click on report map to place a pin first.";
    return;
  }
  const type = document.getElementById("issueType").value;
  const severity = Number(document.getElementById("issueSeverity").value);
  const notes = document.getElementById("reportNotes").value.trim();
  const photoInput = document.getElementById("photoInput");
  const photoFile = photoInput.files[0];
  let photoDataUrl = "";
  if (photoFile) {
    try {
      photoDataUrl = await readFileAsDataUrl(photoFile);
    } catch (error) {
      document.getElementById("pinHint").textContent = "Photo could not be read. Please try another image.";
      document.getElementById("pinHint").classList.add("warning");
      return;
    }
  }
  syncReportsFromStorage();
  state.reports.push(normalizeReport({
    id: crypto.randomUUID(),
    type,
    severity,
    status: "new",
    notes,
    lat: state.selectedPin.lat,
    lng: state.selectedPin.lng,
    areaName: state.selectedReportArea.name,
    hasPhoto: Boolean(photoDataUrl),
    photoDataUrl,
    submittedByUser: true,
    submittedByName: state.currentUser?.name || "Community user",
    submittedByEmail: state.currentUser?.email || "",
    createdAt: Date.now()
  }));
  saveReports();
  document.getElementById("reportNotes").value = "";
  photoInput.value = "";
  document.getElementById("pinHint").textContent = `Report submitted for ${state.selectedReportArea.name}.`;
  document.getElementById("pinHint").classList.remove("warning");
  document.getElementById("reportAreaHint").classList.remove("warning");
  refreshReportViews();
}

function timeAgo(timestamp) {
  const min = Math.floor((Date.now() - timestamp) / 60000);
  if (min < 1) return "just now";
  if (min < 60) return `${min}m ago`;
  return `${Math.floor(min / 60)}h ago`;
}

function initMaps() {
  maps.heroMap = L.map("heroMap", { zoomControl: false, attributionControl: false }).setView([12.9716, 77.5946], 12);
  maps.userRouteMap = L.map("userRouteMap").setView([12.9716, 77.5946], 12);
  maps.reportMap = L.map("reportMap").setView([12.9716, 77.5946], 12);
  if (document.getElementById("officerMap")) {
    maps.officerMap = L.map("officerMap").setView([12.9716, 77.5946], 12);
  }
  if (document.getElementById("hazardMap")) {
    maps.hazardMap = L.map("hazardMap").setView([12.9716, 77.5946], 12);
  }

  Object.values(maps).forEach((map) => {
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);
  });

  if (maps.hazardMap) hazardLayer.addTo(maps.hazardMap);
  if (maps.officerMap) officerLayer.addTo(maps.officerMap);
  routeLayer.addTo(maps.userRouteMap);

  maps.reportMap.on("click", (e) => {
    if (!state.selectedReportArea) {
      document.getElementById("pinHint").textContent = "Search and select area first, then place the pin.";
      document.getElementById("pinHint").classList.add("warning");
      return;
    }
    state.selectedPin = e.latlng;
    if (reportPinMarker) maps.reportMap.removeLayer(reportPinMarker);
    reportPinMarker = L.marker(e.latlng).addTo(maps.reportMap);
    const pinDistanceFromAreaKm = haversineDistanceKm(
      { lat: e.latlng.lat, lng: e.latlng.lng },
      { lat: state.selectedReportArea.lat, lng: state.selectedReportArea.lng }
    );
    document.getElementById("pinHint").textContent =
      `Pin selected: ${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)} (${pinDistanceFromAreaKm.toFixed(2)} km from ${state.selectedReportArea.name})`;
    document.getElementById("pinHint").classList.toggle("warning", pinDistanceFromAreaKm > 3.5);
  });

}

function initParticles() {
  const canvas = document.getElementById("particleCanvas");
  const ctx = canvas.getContext("2d");
  const particles = Array.from({ length: 80 }, () => ({
    x: Math.random(),
    y: Math.random(),
    r: Math.random() * 2.2 + 0.5,
    vx: (Math.random() - 0.5) * 0.0006,
    vy: (Math.random() - 0.5) * 0.0006
  }));
  function resize() {
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
  }
  window.addEventListener("resize", resize);
  resize();
  function tick() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > 1) p.vx *= -1;
      if (p.y < 0 || p.y > 1) p.vy *= -1;
      ctx.beginPath();
      ctx.fillStyle = "rgba(125, 195, 255, 0.55)";
      ctx.arc(p.x * canvas.width, p.y * canvas.height, p.r, 0, Math.PI * 2);
      ctx.fill();
    });
    requestAnimationFrame(tick);
  }
  tick();
}

function initFeatureRotator() {
  const target = document.getElementById("featureHighlight");
  let idx = 0;
  setInterval(() => {
    idx = (idx + 1) % featureHighlights.length;
    target.textContent = featureHighlights[idx];
  }, 2200);
}

function bindEvents() {
  document.getElementById("getStartedBtn").addEventListener("click", () => showPage("login"));
  document.getElementById("goSignupBtn").addEventListener("click", () => showPage("signup"));
  document.getElementById("goLoginBtn").addEventListener("click", () => showPage("login"));
  document.getElementById("loginBtn").addEventListener("click", login);
  document.getElementById("signupBtn").addEventListener("click", signup);

  document.getElementById("homeBtn").addEventListener("click", () => showPage("landing"));
  document.getElementById("enterUserBtn").addEventListener("click", () => {
    if (!state.currentUser) {
      showPage("login");
      return;
    }
    setCurrentUser({ ...state.currentUser, role: "user" });
    goToRoleDashboard("user");
  });
  document.getElementById("enterOfficerBtn").addEventListener("click", () => {
    if (!state.currentUser) {
      showPage("login");
      return;
    }
    setCurrentUser({ ...state.currentUser, role: "officer" });
    goToRoleDashboard("officer");
  });

  document.getElementById("themeToggle").addEventListener("click", () => {
    const next = document.body.classList.contains("light") ? "dark" : "light";
    setTheme(next);
  });
  document.getElementById("findAreaBtn").addEventListener("click", focusReportArea);
  document.getElementById("reportAreaInput").addEventListener("input", () => {
    const typedArea = document.getElementById("reportAreaInput").value.trim().toLowerCase();
    const selectedArea = state.selectedReportArea?.name?.toLowerCase();
    if (!selectedArea || typedArea === selectedArea) return;
    state.selectedReportArea = null;
    state.selectedPin = null;
    if (reportPinMarker) maps.reportMap.removeLayer(reportPinMarker);
    if (reportAreaMarker) maps.reportMap.removeLayer(reportAreaMarker);
    if (reportAreaCircle) maps.reportMap.removeLayer(reportAreaCircle);
    reportPinMarker = null;
    reportAreaMarker = null;
    reportAreaCircle = null;
    document.getElementById("reportAreaHint").textContent = "Area text changed. Click Find Area to refresh map focus.";
    document.getElementById("reportAreaHint").classList.remove("warning");
    document.getElementById("pinHint").textContent = "No pin selected yet.";
    document.getElementById("pinHint").classList.add("warning");
  });

  document.getElementById("findRouteBtn").addEventListener("click", fetchBestRoutes);
  document.getElementById("openGoogleMapsBtn").addEventListener("click", openGoogleMapsLiveRoute);
  document.getElementById("submitReportBtn").addEventListener("click", submitUserReport);

  document.getElementById("applyFiltersBtn").addEventListener("click", refreshReportViews);
  document.getElementById("reportsTableBody").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-id][data-action]");
    if (!btn || btn.disabled) return;
    syncReportsFromStorage();
    const reportIndex = state.reports.findIndex((r) => r.id === btn.dataset.id);
    if (reportIndex < 0) return;
    const report = state.reports[reportIndex];

    if (btn.dataset.action === "delete") {
      if (report.status !== "resolved") return;
      state.reports.splice(reportIndex, 1);
    } else if (btn.dataset.action === "set-status") {
      if (!btn.dataset.next) return;
      report.status = btn.dataset.next;
    } else {
      return;
    }
    saveReports();
    refreshReportViews();
  });

  document.getElementById("classifySurfaceBtn").addEventListener("click", analyzeRoadSurface);
  document.getElementById("runFeasibilityBtn").addEventListener("click", runFeasibilityAnalysis);
}

function bootstrap() {
  migrateLegacyUsersIfNeeded();
  setTheme(localStorage.getItem("theme") || "dark");
  initMaps();
  initParticles();
  initFeatureRotator();
  bindEvents();
  refreshReportViews();
  window.addEventListener("storage", (event) => {
    if (event.key === REPORTS_STORAGE_KEY) refreshReportViews();
  });
  if (state.currentUser?.role) {
    goToRoleDashboard(state.currentUser.role);
  } else if (state.currentUser) {
    showPage("role");
  }
}

bootstrap();
