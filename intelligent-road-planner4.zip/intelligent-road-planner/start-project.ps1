$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$entryFile = Join-Path $projectRoot "index.html"

if (-not (Test-Path $entryFile)) {
  Write-Error "index.html not found at $entryFile"
  exit 1
}

Start-Process $entryFile
Write-Host "Project launched: $entryFile"
